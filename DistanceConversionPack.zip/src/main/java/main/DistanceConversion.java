package main;
import ConversionDemo.DistanceConverter;
public class DistanceConversion
{
    public static void main(String[] args)
    {
        DistanceConverter d=new DistanceConverter();
        System.out.println("Convert Meters to KMs: "+d.MeterstoKMs(10));
        System.out.println("Convert KMs to Meters: "+d.KMstoMeters(10));
        System.out.println("Convert Miles to KMs: "+d.MilestoKMs(10));
        System.out.println("Convert KMs to Miles: "+d.KMstoMiles(10));

    }
    
}
