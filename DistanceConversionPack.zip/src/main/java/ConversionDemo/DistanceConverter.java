package ConversionDemo;
public class DistanceConverter 
{
    public double MeterstoKMs(double Meters)
    {
        double KMs=0;
        KMs=Meters/1000;
        return KMs;
    }
    public double KMstoMeters(double KMs)
    {
        double Meters=0;
        Meters=KMs*1000;
        return Meters;
    }
    public double MilestoKMs(double Miles)
    {
        double KMs=0;
        KMs=Miles/0.621;
        return KMs;
    }
    public double KMstoMiles(double KMs)
    {
        double Miles=0;
        Miles=KMs*0.621;
        return Miles;
    }
    
}
   