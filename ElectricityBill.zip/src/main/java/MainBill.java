import java.util.Scanner;
class ElectricityBill
{
    int Consumerno;
    String Consumername;
    double PreviousMonthReading;
    double CurrentMonthReading;
    String EBConnectionType;
    ElectricityBill(int Consumerno,String Consumername,double PreviousMonthReading,double CurrentMonthReading)
    {
        this.Consumerno=Consumerno;
        this.Consumername=Consumername;
        this.PreviousMonthReading=PreviousMonthReading;
        this.CurrentMonthReading=CurrentMonthReading;   
    }
    void EBBill()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Consumer no:"+Consumerno);
        System.out.println("Consumer name:"+Consumername);
        System.out.println("Previous month reading:"+PreviousMonthReading); 
        System.out.println("Current month reading:"+CurrentMonthReading);
        double TR=PreviousMonthReading+CurrentMonthReading;
        System.out.println("Enter the type of EB Connection :(Domestic/Commercial)");
        EBConnectionType = sc.next();
        switch(EBConnectionType)
        {
            case "Domestic":
                if(TR<=100)
                {
                    System.out.println("Amount=Rs."+TR*2);
                }
                else if((TR>100)&&(TR<200))
                {
             
                    System.out.println("Amount=Rs."+TR*3.50);
                }
                else if((TR>200)&&(TR<500))
                {
                 
                    System.out.println("Amount=Rs."+TR*4);
                }
                else
                {
                    
                    System.out.println("Amount=Rs."+TR*6);
                }
                break;
            case "Commercial":
                if(TR<=100)
                {
              
                    System.out.println("Amount=Rs."+TR*3);
                }
                else if((TR>100)&&(TR<200))
                {
                  
                    System.out.println("Amount=Rs."+TR*5.50);
                }
                else if((TR>200)&&(TR<500))
                {
                  
                    System.out.println("Amount=Rs."+TR*6);
                }
                else
                {
                   
                    System.out.println("Amount=Rs."+TR*7);
                }
                break;
            default:
                System.out.println("Please Enter valid choice");
        }
    }
}
public class MainBill
{
    public static void main(String[] args)
    {
        
        ElectricityBill E =new ElectricityBill(21,"Aarthy",50.0,200.0);
        E.EBBill();
       
    }
    
}
