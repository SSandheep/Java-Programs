package ConversionDemo;
public class CurrencyConverter 
{
    double ER=0;
    public double DollarsToINR(double Dollars)
    {
        double INR=0;
        ER=61.06;
        INR=Dollars*ER;
        return INR; 
    }
    public double INRToDollars(double INR)
    {
        double Dollars=0;
        ER=61.06;
        Dollars=INR/ER;
        return Dollars;
    }
    public double EurosToINR(double Euros)
    {
        double INR=0;
        ER=85.42;
        INR=Euros*ER;
        return INR;
    }
    public double INRToEuros(double INR)
    {
        double Euros=0;
        ER=85.42;
        Euros=INR/ER;
        return Euros;
    }
    public double YenToINR(double Yen)
    {
        double INR=0;
        ER=26.2;
        INR=Yen*ER;
        return INR;
    }
    public double INRToYen(double INR)
    {
        double Yen=0;
        ER=26.2;
        Yen=INR/ER;
        return Yen;
    }    
}
