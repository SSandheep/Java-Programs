package Main;
import ConversionDemo.CurrencyConverter;
public class Pack
{
    public static void main(String[] args) 
    {
        CurrencyConverter C =new CurrencyConverter();
        System.out.println("Convert Dollars to INR "+C.DollarsToINR(80.0));
        System.out.println("Convert INR to Dollars "+C.INRToDollars(80.0));
        System.out.println("Convert Euros to INR "+C.EurosToINR(80.0));
        System.out.println("Convert INR to Euros "+C.INRToEuros(80.0));
        System.out.println("Convert Yen to INR "+C.YenToINR(80.0));
        System.out.println("Convert INR to Yen "+C.INRToYen(80.0));
    }
}
